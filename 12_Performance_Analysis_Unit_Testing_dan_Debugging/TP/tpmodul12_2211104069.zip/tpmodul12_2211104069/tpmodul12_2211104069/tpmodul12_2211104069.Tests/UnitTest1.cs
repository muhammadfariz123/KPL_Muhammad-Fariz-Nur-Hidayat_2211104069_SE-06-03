﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using tpmodul12_2211104069; // Pastikan sesuai dengan namespace project utama

namespace tpmodul12_2211104069.Tests
{
    [TestClass]
    public class Form1Tests
    {
        [TestMethod]
        public void Test_Negatif()
        {
            var form = new Form1();
            Assert.AreEqual("Negatif", form.InvokeCariTandaBilangan(-5));
        }

        [TestMethod]
        public void Test_Positif()
        {
            var form = new Form1();
            Assert.AreEqual("Positif", form.InvokeCariTandaBilangan(7));
        }

        [TestMethod]
        public void Test_Nol()
        {
            var form = new Form1();
            Assert.AreEqual("Nol", form.InvokeCariTandaBilangan(0));
        }
    }
}
