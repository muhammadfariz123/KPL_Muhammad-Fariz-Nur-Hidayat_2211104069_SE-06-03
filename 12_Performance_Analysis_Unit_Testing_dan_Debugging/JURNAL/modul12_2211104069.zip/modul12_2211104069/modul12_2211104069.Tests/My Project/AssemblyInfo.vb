﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

<Assembly: AssemblyTitle("modul12_2211104069.Tests")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("modul12_2211104069.Tests")>
<Assembly: AssemblyCopyright("Copyright ©  2025")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

<Assembly: Guid("e5aa4ee3-55ca-4659-bd74-e59988cfca70")>

' <Assembly: AssemblyVersion("1.0.*")> 
<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
