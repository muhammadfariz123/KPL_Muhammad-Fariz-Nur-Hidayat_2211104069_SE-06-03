﻿Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()>
Public Class UnitTest1

    <TestMethod()>
    Public Sub Test_B_Positif()
        Dim form As New Form1()
        Assert.AreEqual(8, form.InvokeCariNilaiPangkat(2, 3))
    End Sub

    <TestMethod()>
    Public Sub Test_B_Nol()
        Dim form As New Form1()
        Assert.AreEqual(1, form.InvokeCariNilaiPangkat(2, 0))
    End Sub

    <TestMethod()>
    Public Sub Test_B_Negatif()
        Dim form As New Form1()
        Assert.AreEqual(-1, form.InvokeCariNilaiPangkat(2, -1))
    End Sub

    <TestMethod()>
    Public Sub Test_LebihDariBatas()
        Dim form As New Form1()
        Assert.AreEqual(-2, form.InvokeCariNilaiPangkat(101, 2))
    End Sub

    <TestMethod()>
    Public Sub Test_Overflow()
        Dim form As New Form1()
        Assert.AreEqual(-3, form.InvokeCariNilaiPangkat(50, 10))
    End Sub

End Class
