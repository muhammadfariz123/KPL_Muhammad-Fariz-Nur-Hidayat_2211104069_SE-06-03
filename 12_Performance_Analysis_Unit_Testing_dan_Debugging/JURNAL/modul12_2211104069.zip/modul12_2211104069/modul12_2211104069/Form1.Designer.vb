﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TextBoxA = New System.Windows.Forms.TextBox()
        Me.TextBoxB = New System.Windows.Forms.TextBox()
        Me.buttonHitung = New System.Windows.Forms.Button()
        Me.labelHasil = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TextBoxA
        '
        Me.TextBoxA.Location = New System.Drawing.Point(98, 38)
        Me.TextBoxA.Name = "TextBoxA"
        Me.TextBoxA.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxA.TabIndex = 0
        '
        'TextBoxB
        '
        Me.TextBoxB.Location = New System.Drawing.Point(243, 38)
        Me.TextBoxB.Name = "TextBoxB"
        Me.TextBoxB.Size = New System.Drawing.Size(100, 20)
        Me.TextBoxB.TabIndex = 1
        '
        'buttonHitung
        '
        Me.buttonHitung.Location = New System.Drawing.Point(186, 106)
        Me.buttonHitung.Name = "buttonHitung"
        Me.buttonHitung.Size = New System.Drawing.Size(75, 23)
        Me.buttonHitung.TabIndex = 2
        Me.buttonHitung.Text = "Hitung"
        Me.buttonHitung.UseVisualStyleBackColor = True
        '
        'labelHasil
        '
        Me.labelHasil.AutoSize = True
        Me.labelHasil.Location = New System.Drawing.Point(202, 72)
        Me.labelHasil.Name = "labelHasil"
        Me.labelHasil.Size = New System.Drawing.Size(0, 13)
        Me.labelHasil.TabIndex = 3
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.labelHasil)
        Me.Controls.Add(Me.buttonHitung)
        Me.Controls.Add(Me.TextBoxB)
        Me.Controls.Add(Me.TextBoxA)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBoxA As TextBox
    Friend WithEvents TextBoxB As TextBox
    Friend WithEvents buttonHitung As Button
    Friend WithEvents labelHasil As Label
End Class
