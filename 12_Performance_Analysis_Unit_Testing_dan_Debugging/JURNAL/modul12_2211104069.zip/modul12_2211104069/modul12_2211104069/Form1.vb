﻿Public Class Form1

    ' Event Load Form
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Kosong, tidak perlu isi apa-apa
    End Sub

    ' Method untuk mencari nilai pangkat dengan aturan khusus
    Private Function CariNilaiPangkat(a As Integer, b As Integer) As Integer
        If b = 0 Then
            Return 1
        End If

        If b < 0 Then
            Return -1
        End If

        If b > 10 OrElse a > 100 Then
            Return -2
        End If

        Try
            Dim hasil As Integer = 1
            For i As Integer = 1 To b
                hasil = checkedMultiply(hasil, a)
            Next
            Return hasil
        Catch ex As OverflowException
            Return -3
        End Try
    End Function

    ' Fungsi bantu untuk melakukan perkalian terproteksi overflow
    Private Function checkedMultiply(x As Integer, y As Integer) As Integer
        Dim result As Long = CLng(x) * CLng(y)
        If result > Integer.MaxValue OrElse result < Integer.MinValue Then
            Throw New OverflowException()
        End If
        Return CInt(result)
    End Function

    ' Public wrapper agar bisa diakses dari unit test
    Public Function InvokeCariNilaiPangkat(a As Integer, b As Integer) As Integer
        Return CariNilaiPangkat(a, b)
    End Function

    ' Event Button Hitung diklik
    Private Sub buttonHitung_Click(sender As Object, e As EventArgs) Handles buttonHitung.Click
        Dim a, b As Integer
        If Integer.TryParse(TextBoxA.Text, a) AndAlso Integer.TryParse(TextBoxB.Text, b) Then
            Dim hasil As Integer = CariNilaiPangkat(a, b)
            labelHasil.Text = $"Hasil: {hasil}"
        Else
            labelHasil.Text = "Input tidak valid!"
        End If
    End Sub

    Private Sub TextBoxA_TextChanged(sender As Object, e As EventArgs) Handles TextBoxA.TextChanged
        ' Bisa dikosongkan atau isi sesuai kebutuhan
    End Sub

    Private Sub TextBoxB_TextChanged(sender As Object, e As EventArgs) Handles TextBoxB.TextChanged
        ' Bisa dikosongkan atau isi sesuai kebutuhan
    End Sub

End Class
