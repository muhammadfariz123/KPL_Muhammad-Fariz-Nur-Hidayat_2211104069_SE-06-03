﻿namespace modul9_2211104069.Controllers
{
    using Microsoft.AspNetCore.Mvc; // Untuk ControllerBase dan ActionResult
    using modul9_2211104069.Models; // Mengimpor Movie dari Models
    using System.Collections.Generic;

    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        // Static list untuk menyimpan data film
        public static List<Movie> Movies = new List<Movie>
        {
            new Movie
            {
                Title = "The Shawshank Redemption",
                Director = "Frank Darabont",
                Stars = new List<string> { "Tim Robbins", "Morgan Freeman" },
                Description = "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency."
            },
            new Movie
            {
                Title = "The Godfather",
                Director = "Francis Ford Coppola",
                Stars = new List<string> { "Marlon Brando", "Al Pacino" },
                Description = "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son."
            },
            new Movie
            {
                Title = "The Dark Knight",
                Director = "Christopher Nolan",
                Stars = new List<string> { "Christian Bale", "Heath Ledger" },
                Description = "When the menace known as the Joker emerges from his mysterious past, he wreaks havoc and chaos on the people of Gotham."
            }
        };

        // GET /api/Movies: Mengembalikan semua movie
        [HttpGet]
        public IActionResult GetMovies()
        {
            return Ok(Movies); // Mengembalikan seluruh list film
        }

        // GET /api/Movies/{id}: Mengembalikan movie berdasarkan ID
        [HttpGet("{id}")]
        public IActionResult GetMovie(int id)
        {
            // Memeriksa apakah ID valid
            if (id < 0 || id >= Movies.Count)
            {
                return NotFound(); // Jika ID tidak ditemukan, kembalikan 404 NotFound
            }

            return Ok(Movies[id]); // Mengembalikan movie berdasarkan ID
        }

        // POST /api/Movies: Menambahkan movie baru
        [HttpPost]
        public IActionResult AddMovie([FromBody] Movie newMovie)
        {
            if (newMovie == null)
            {
                return BadRequest("Movie data is required."); // Memastikan data valid
            }

            Movies.Add(newMovie); // Menambahkan movie ke dalam list
            return CreatedAtAction(nameof(GetMovie), new { id = Movies.Count - 1 }, newMovie); // Mengembalikan HTTP 201 Created
        }

        // DELETE /api/Movies/{id}: Menghapus movie berdasarkan ID
        [HttpDelete("{id}")]
        public IActionResult DeleteMovie(int id)
        {
            // Memeriksa apakah ID valid
            if (id < 0 || id >= Movies.Count)
            {
                return NotFound(); // Jika ID tidak ditemukan, kembalikan 404 NotFound
            }

            Movies.RemoveAt(id); // Menghapus movie berdasarkan ID
            return NoContent(); // Mengembalikan HTTP 204 No Content (berhasil menghapus)
        }
    }
}
