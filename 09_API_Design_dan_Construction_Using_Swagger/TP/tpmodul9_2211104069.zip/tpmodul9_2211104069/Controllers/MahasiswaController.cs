﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using tpmodul9_2211104069.Models;  
namespace tpmodul9_2211104069.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MahasiswaController : ControllerBase
    {
        // Daftar mahasiswa statis
        private static List<Mahasiswa> mahasiswaList = new List<Mahasiswa>
        {
            new Mahasiswa { Nama = "Muhammad Fariz Nur Hidayat", Nim = "2211104069" },
            new Mahasiswa { Nama = "Putra Pratama Okta Riano", Nim = "2211104068" },
            new Mahasiswa { Nama = "Allaya Daffa Zhilal", Nim = "2211104090" },
            new Mahasiswa { Nama = "Naufal Aflakh Wijayanto", Nim = "2211104073" }
        };

        // Endpoint GET untuk mengambil daftar mahasiswa
        [HttpGet]
        public ActionResult<IEnumerable<Mahasiswa>> GetMahasiswa()
        {
            return Ok(mahasiswaList);
        }

        // Endpoint GET untuk mengambil mahasiswa berdasarkan index
        [HttpGet("{index}")]
        public ActionResult<Mahasiswa> GetMahasiswaByIndex(int index)
        {
            if (index < 0 || index >= mahasiswaList.Count)
                return NotFound();  // Mengembalikan 404 jika index tidak ditemukan

            return Ok(mahasiswaList[index]);
        }

        // Endpoint POST untuk menambahkan mahasiswa baru
        [HttpPost]
        public ActionResult AddMahasiswa([FromBody] Mahasiswa mahasiswa)
        {
            mahasiswaList.Add(mahasiswa);
            return CreatedAtAction(nameof(GetMahasiswa), new { index = mahasiswaList.Count - 1 }, mahasiswa);
        }

        // Endpoint DELETE untuk menghapus mahasiswa berdasarkan index
        [HttpDelete("{index}")]
        public ActionResult DeleteMahasiswa(int index)
        {
            if (index < 0 || index >= mahasiswaList.Count)
                return NotFound();  // Mengembalikan 404 jika index tidak ditemukan

            mahasiswaList.RemoveAt(index);
            return NoContent();  // Mengembalikan status 204 jika penghapusan berhasil
        }
    }
}
