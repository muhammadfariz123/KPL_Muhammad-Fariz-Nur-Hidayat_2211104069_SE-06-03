﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tpmodul13_2211104069
{
    // Subject interface
    interface ISubject
    {
        void Attach(IObserver observer);
        void Detach(IObserver observer);
        void Notify();
    }

    // Observer interface
    interface IObserver
    {
        void Update(ISubject subject);
    }

    // Concrete Subject
    class ConcreteSubject : ISubject
    {
        private List<IObserver> observers = new List<IObserver>();

        private int state;
        public int State
        {
            get { return state; }
            set
            {
                state = value;
                Notify(); // notify observers ketika state berubah
            }
        }

        public void Attach(IObserver observer)
        {
            observers.Add(observer);
        }

        public void Detach(IObserver observer)
        {
            observers.Remove(observer);
        }

        public void Notify()
        {
            foreach (var observer in observers)
            {
                observer.Update(this);
            }
        }
    }

    // Concrete Observer A
    class ConcreteObserverA : IObserver
    {
        public void Update(ISubject subject)
        {
            if (subject is ConcreteSubject concreteSubject)
            {
                if (concreteSubject.State < 3)
                {
                    Console.WriteLine("ConcreteObserverA: State kurang dari 3, State = " + concreteSubject.State);
                }
            }
        }
    }

    // Concrete Observer B
    class ConcreteObserverB : IObserver
    {
        public void Update(ISubject subject)
        {
            if (subject is ConcreteSubject concreteSubject)
            {
                if (concreteSubject.State >= 3)
                {
                    Console.WriteLine("ConcreteObserverB: State lebih atau sama dengan 3, State = " + concreteSubject.State);
                }
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // Membuat subject
            var subject = new ConcreteSubject();

            // Membuat observer
            var observerA = new ConcreteObserverA();
            var observerB = new ConcreteObserverB();

            // Attach observer ke subject
            subject.Attach(observerA);
            subject.Attach(observerB);

            // Mengubah state dan melihat hasil observer
            Console.WriteLine("Set state ke 2.");
            subject.State = 2;

            Console.WriteLine("Set state ke 3.");
            subject.State = 3;

            Console.WriteLine("Set state ke 5.");
            subject.State = 5;

            // Tunggu user tekan enter untuk keluar
            Console.WriteLine("Tekan enter untuk keluar...");
            Console.ReadLine();
        }
    }
}