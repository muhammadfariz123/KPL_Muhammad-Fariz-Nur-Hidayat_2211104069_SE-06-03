﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modul13_2211104069
{
    public class PusatDataSingleton
    {
        // Property singleton: instance tunggal
        private static PusatDataSingleton _instance;

        // Atribut data tersimpan berupa List<string>
        private List<string> DataTersimpan;

        // Konstruktor private agar tidak bisa diakses luar kelas
        private PusatDataSingleton()
        {
            DataTersimpan = new List<string>();
        }

        // Method untuk mendapatkan instance singleton
        public static PusatDataSingleton GetDataSingleton()
        {
            if (_instance == null)
            {
                _instance = new PusatDataSingleton();
            }
            return _instance;
        }

        // Mengembalikan list data tersimpan
        public List<string> GetSemuaData()
        {
            return DataTersimpan;
        }

        // Mencetak semua data yang tersimpan
        public void PrintSemuaData()
        {
            Console.WriteLine("Data Tersimpan:");
            for (int i = 0; i < DataTersimpan.Count; i++)
            {
                Console.WriteLine($"{i}: {DataTersimpan[i]}");
            }
        }

        // Menambahkan sebuah data baru ke list
        public void AddSebuahData(string input)
        {
            DataTersimpan.Add(input);
        }

        // Menghapus data berdasarkan index tertentu
        public void HapusSebuahData(int index)
        {
            if (index >= 0 && index < DataTersimpan.Count)
            {
                DataTersimpan.RemoveAt(index);
            }
            else
            {
                Console.WriteLine("Index tidak valid.");
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            // A. Membuat dua variabel dengan tipe PusatDataSingleton
            var data1 = PusatDataSingleton.GetDataSingleton();
            var data2 = PusatDataSingleton.GetDataSingleton();

            // B. Mengisi data1 dengan beberapa data nama anggota dan asisten praktikum
            data1.AddSebuahData("Anggota 1: Andi");
            data1.AddSebuahData("Anggota 2: Budi");
            data1.AddSebuahData("Anggota 3: Cici");
            data1.AddSebuahData("Asisten Praktikum: Pak Dedi");

            // C. Memanggil PrintSemuaData() melalui data2 untuk menampilkan semua data
            Console.WriteLine("Data dari data2:");
            data2.PrintSemuaData();

            // D. Menghapus nama asisten praktikum melalui data2 (misal index 3)
            data2.HapusSebuahData(3);

            // E. Memanggil PrintSemuaData() melalui data1, asisten seharusnya sudah hilang
            Console.WriteLine("\nData dari data1 setelah penghapusan:");
            data1.PrintSemuaData();

            // F. Menampilkan jumlah data di data1 dan data2
            Console.WriteLine($"\nJumlah data di data1: {data1.GetSemuaData().Count}");
            Console.WriteLine($"Jumlah data di data2: {data2.GetSemuaData().Count}");

            Console.WriteLine("\nTekan Enter untuk keluar...");
            Console.ReadLine();
        }
    }
}
